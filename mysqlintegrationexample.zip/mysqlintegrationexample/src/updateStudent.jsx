import { useState, useEffect } from 'react'; 
import { fetchStudents, updateStudent } from './api.js'; 
function updateStudent(){
const [students, setStudents] = useState([]); 
 const [form, setForm] = useState({stdid:'', stdname: '', standard: '',  
      roll: '', age: '' }); 
  
 useEffect(() => { 
     getStudents(); 
 }, []); 
  
 const getStudents = async () => { 
     const data = await fetchStudents(); 
     setStudents(data); 
 }; 
 //to set data on change in form elements 
 const handleChange = (e) => { 
     setForm({ ...form, [e.target.name]: e.target.value }); 
 }; 
  
 const handleSubmit = async (e) => { 
     e.preventDefault(); 
     if (form.stdid && form.stdname && form.standard && form.roll &&  
     form.age)  
     { 
         await updateStudent(form); 
         setForm({stdid:'', stdname: '', standard: '', roll: '', age: ''  
           }); 
         
     } 
 }; 

    return (
        <div>
            <h2 >Update Student</h2>
            
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    name="stdid"
                    placeholder="Student ID"
                    value={formData.stdid}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="stdname"
                    placeholder="Student Name"
                    value={formData.stdname}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="standard"
                    placeholder="Standard"
                    value={formData.standard}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="roll"
                    placeholder="Roll Number"
                    value={formData.roll}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="age"
                    placeholder="Age"
                    value={formData.age}
                    onChange={handleChange}
                    required
                />
                <button type="submit" >
                    Update Student
                </button>
            </form>
        </div>
    );

};
export default updateStudent;
