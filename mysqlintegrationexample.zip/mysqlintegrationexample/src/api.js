import axios from 'axios'; 
  
// Fetch students 
export async function fetchStudents() { 
 try { 
     const response = await axios.get('/api/students'); 
     return response.data; 
 } catch (error) { 
     console.error('Error fetching students:', error); 
     return []; 
 } 
} 
  
// Add a student
export async function addStudent(student) { 
    try { 
        const response = await axios.post('/api/students', student); 
        return response.data; 
    } catch (error) { 
        console.error('Error adding student:', error); 
        return { error: error.message }; 
    } 
   }
   export async function updateStudent(student) { 
    try { 
        const response = await axios.post('/api/students', student); 
        return response.data; 
    } catch (error) { 
        console.error('Error adding student:', error); 
        return { error: error.message }; 
    } 
   }