import { useState, useEffect } from 'react'; 
import { fetchStudents, addStudent } from './api.js'; 
import  updateStudent  from './updateStudent.jsx';
  
function App() { 
 const [students, setStudents] = useState([]); 
 const [form, setForm] = useState({stdid:'', stdname: '', standard: '',  
      roll: '', age: '' }); 
  
 useEffect(() => { 
     getStudents(); 
 }, []); 
  
 const getStudents = async () => { 
     const data = await fetchStudents(); 
     setStudents(data); 
 }; 
 //to set data on change in form elements 
 const handleChange = (e) => { 
     setForm({ ...form, [e.target.name]: e.target.value }); 
 }; 
  
 const handleSubmit = async (e) => { 
     e.preventDefault(); 
     if (form.stdid && form.stdname && form.standard && form.roll &&  
     form.age)  
     { 
         await addStudent(form); 
         setForm({stdid:'', stdname: '', standard: '', roll: '', age: ''  
           }); 
         getStudents(); // Refresh student list 
     } 
 }; 
  
 return ( 
     <div className="container"> 
         <h1>Student List</h1> 
         <ul> 
             {students.map((student) => ( 
                 <li key={student.stdid}> 
                     {student.stdname} - Class {student.standard}, Roll: 
{student.roll}, Age: {student.age} 
                 </li> 
             ))} 
         </ul> 
  
         <h2>Add Student</h2> 
         <form onSubmit={handleSubmit}> 
             <input type="text" name="stdid" placeholder="Studentid" 
value={form.stdid} onChange={handleChange} /> 
             <input type="text" name="stdname" placeholder="Name" 
value={form.stdname} onChange={handleChange} /> 
             <input type="text" name="standard" placeholder="Class" 
value={form.standard} onChange={handleChange} /> 
             <input type="number" name="roll" placeholder="Roll No" 
value={form.roll} onChange={handleChange} /> 
             <input type="number" name="age" placeholder="Age" 
value={form.age} onChange={handleChange} /> 
             <button type="submit">Add Student</button> 
         </form> 
<updateStudent/>
     </div> 
 ); 
} 
  
export default App; 