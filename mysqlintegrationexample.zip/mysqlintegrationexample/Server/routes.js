import express from 'express'; 
import { getStudents, addStudent,updateStudent } from './studentController.js'; 
  
const router = express.Router(); 
  
router.get('/students', getStudents); 
router.post('/students', addStudent); 
router.post('/students',updateStudent); 
export default router; 