import pool from './db.js'; // Import database connection 
  
// Fetch all students 
export async function getStudents(req, res) { 
 try { 
     const [rows] = await pool.query('SELECT * FROM student'); 
     res.json(rows); 
 } catch (err) { 
     console.error('Error fetching students:', err); 
     res.status(500).json({ error: 'Internal Server Error' }); 
 } 
} 
  
// Add a student 
export async function addStudent(req, res) { 
 const { stdid, stdname, standard, roll, age } = req.body; 
  
 try { 
     const [result] = await pool.query( 
         'INSERT INTO student (stdid, stdname, standard, roll, age) VALUES (?, ?, ?, ?, ?)',
[stdid, stdname, standard, roll, age] 
     ); 
  
     res.json({ message: 'Student added successfully', insertedId: 
result.insertId }); 
 } catch (err) { 
     console.error('Error adding student:', err); 
     res.status(500).json({ error: 'Internal Server Error' }); 
 } 
} 


export async function updateStudent(req, res) {
    try {
        const { stdid, stdname, standard, roll, age } = req.body;

        // Basic validation
        if (!stdid || !stdname || !standard || !roll || !age) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        // Update student record in the database
        const [result] = await pool.query(
            'UPDATE student SET stdname = ?, standard = ?, roll = ?, age = ? WHERE stdid = ?',
            [stdname, standard, roll, age, stdid]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        res.status(200).json({ message: 'Student updated successfully' });
    } catch (err) {
        console.error('Error updating student:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
